@echo off
setlocal
cd /d "%~dp0"
title HIGH YIELD - VIT Past Paper Analysis
set "PYTHON_CMD="
rem Prefer a well-supported Python version when the Windows launcher has it.
where py >nul 2>nul
if not errorlevel 1 (
  py -3.12 --version >nul 2>nul && set "PYTHON_CMD=py -3.12"
  if not defined PYTHON_CMD py -3.13 --version >nul 2>nul && set "PYTHON_CMD=py -3.13"
  if not defined PYTHON_CMD py -3 --version >nul 2>nul && set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD where python >nul 2>nul && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
  echo Python 3 was not found. Install Python 3.11 or newer from https://www.python.org/downloads/ and enable Add Python to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating the project environment...
  %PYTHON_CMD% -m venv .venv
  if errorlevel 1 (echo Could not create the virtual environment.& pause & exit /b 1)
)
if not exist ".venv\deps-installed" (
  echo Installing HIGH YIELD dependencies. This needs internet on first launch...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip
  if errorlevel 1 (echo Dependency setup failed.& pause & exit /b 1)
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (echo Required dependency setup failed. Check internet access and Python compatibility.& pause & exit /b 1)
  rem RapidOCR is optional: its ONNX runtime wheel may not exist for newer Python versions.
  rem Never let optional OCR stop the core app from installing or launching.
  ".venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info < (3,14) else 1)"
  if not errorlevel 1 (
    echo Installing optional RapidOCR support...
    ".venv\Scripts\python.exe" -m pip install "rapidocr-onnxruntime>=1.3"
    if errorlevel 1 echo Optional RapidOCR unavailable; app will use Tesseract if installed.
  ) else (
    echo Python 3.14 detected; skipping incompatible optional RapidOCR package.
    echo For scanned PDFs, install Tesseract OCR or use Python 3.12/3.13 for optional RapidOCR.
  )
  echo ready>.venv\deps-installed
)
if not exist "data\uploads" mkdir "data\uploads"
rem Find a free local port from 8000 through 8010 so an older project instance does not block launch.
set "APP_PORT=8000"
:chooseport
powershell -NoProfile -Command "$p=%APP_PORT%; try { $l=[System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$p); $l.Start(); $l.Stop(); exit 0 } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto portready
set /a APP_PORT+=1
if %APP_PORT% GTR 8010 goto portfail
goto chooseport
:portready
echo Starting HIGH YIELD on port %APP_PORT%...
start "HIGH YIELD server" /min /D "%~dp0" "%~dp0.venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port %APP_PORT%
set /a tries=0
:wait
set /a tries+=1
if %tries% GEQ 30 goto timeout
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:%APP_PORT%/api/subjects -TimeoutSec 1; if ($r.StatusCode -eq 200 -and $r.Content.Contains('subjects')) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto open
timeout /t 1 /nobreak >nul
goto wait
:open
start "" http://127.0.0.1:%APP_PORT%/
echo HIGH YIELD is running at http://127.0.0.1:%APP_PORT%/
echo Keep the server window running while you use the app.
exit /b 0
:portfail
echo Ports 8000 through 8010 are busy. Close another local server and try again.
pause
exit /b 1
:timeout
echo The app did not respond on port %APP_PORT%. Check the server window for the error.
pause
exit /b 1
