# GitHub submission checklist

- [ ] Review each PDF manually and verify it is a genuine exam paper.
- [ ] Fill subject, exam, year, semester, slot, source URL and document type; never guess.
- [ ] Review/correct concept labels.
- [ ] Run the notebook and retain actual metrics/confusion matrices only.
- [ ] Confirm `.gitignore` excludes uploads, SQLite DB, processed data and model artifacts.
- [ ] Create a GitHub repository and push the project using your own authorized account.
- [ ] Add the actual dataset/source links and repository URL to the final submission.

No GitHub push or real-PDF authenticity verification is claimed by this package.
