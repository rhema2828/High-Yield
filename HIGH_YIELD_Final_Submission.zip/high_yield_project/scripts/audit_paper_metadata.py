"""Create a metadata audit report from the local HIGH YIELD SQLite database.
This script flags missing/unverified metadata; it does not certify PDFs as genuine.
Run from the project root with: python scripts/audit_paper_metadata.py
"""
import csv, sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
db = root / "data" / "high_yield.sqlite3"
out = root / "data" / "paper_metadata_audit.csv"
if not db.exists():
    print("No local database exists yet. Launch the app and analyse PDFs first.")
    raise SystemExit(0)
con = sqlite3.connect(db)
con.row_factory = sqlite3.Row
cols = {r[1] for r in con.execute("PRAGMA table_info(papers)")}
needed = ["filename", "sha256", "subject", "exam", "year", "semester", "slot", "status", "error"]
selected = [c for c in needed if c in cols]
rows = [dict(r) for r in con.execute("SELECT " + ",".join(selected) + " FROM papers")]
fields = selected + ["metadata_flags", "verified_genuine_exam_paper", "source_url", "document_type", "review_notes"]
with out.open("w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
    for r in rows:
        flags=[]
        for key in ("subject", "exam", "year"):
            if not str(r.get(key) or "").strip(): flags.append("missing_"+key)
        if r.get("status") != "processed": flags.append("not_processed")
        r.update(metadata_flags=";".join(flags), verified_genuine_exam_paper="UNVERIFIED", source_url="", document_type="", review_notes="")
        w.writerow(r)
print(f"Wrote {len(rows)} records to {out}")
print("Review each document and fill source_url, document_type, and verified_genuine_exam_paper manually.")
