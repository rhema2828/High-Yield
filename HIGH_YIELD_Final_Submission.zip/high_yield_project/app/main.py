from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
import sqlite3, json, hashlib, re, shutil, uuid, os, datetime
from collections import defaultdict

BASE=Path(__file__).resolve().parent.parent
DATA=BASE/'data'; UPLOADS=DATA/'uploads'; STATIC=BASE/'static'; DB=DATA/'high_yield.sqlite3'
for p in (UPLOADS, DATA/'processed', STATIC): p.mkdir(parents=True,exist_ok=True)
SYLLABUS=json.loads((DATA/'syllabus.json').read_text(encoding='utf-8'))
SUBJECTS=[s['name'] for s in SYLLABUS]; EXAMS=['CAT-1','CAT-2','FAT']
app=FastAPI(title='HIGH YIELD API',version='1.0.0')
app.mount('/static',StaticFiles(directory=STATIC),name='static')

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    with db() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS papers(id TEXT PRIMARY KEY, filename TEXT, stored_name TEXT, subject TEXT, exam TEXT, year TEXT, semester TEXT, slot TEXT, sha256 TEXT UNIQUE, status TEXT, error TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS questions(id TEXT PRIMARY KEY, paper_id TEXT, question_no TEXT, text TEXT, FOREIGN KEY(paper_id) REFERENCES papers(id));
        CREATE TABLE IF NOT EXISTS concepts(id TEXT PRIMARY KEY, subject TEXT, module TEXT, name TEXT);
        CREATE TABLE IF NOT EXISTS question_concepts(question_id TEXT, concept_id TEXT, confidence REAL, verified INTEGER DEFAULT 0, FOREIGN KEY(question_id) REFERENCES questions(id), FOREIGN KEY(concept_id) REFERENCES concepts(id), UNIQUE(question_id,concept_id));
        CREATE TABLE IF NOT EXISTS model_runs(id TEXT PRIMARY KEY, model TEXT, subject TEXT, exam TEXT, samples INTEGER, metrics TEXT, status TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS model_estimates(subject TEXT, exam TEXT, concept_id TEXT, model TEXT, estimate REAL, run_at TEXT, PRIMARY KEY(subject,exam,concept_id,model));
        ''')
        # Synchronise the database with the complete bundled syllabus on every launch.
        # Existing concept IDs are preserved so old paper mappings remain linked.
        for subj in SYLLABUS:
            expected=set()
            for mod in subj['modules']:
                for concept_name in mod['concepts']:
                    expected.add(concept_name)
                    existing=c.execute('SELECT id FROM concepts WHERE subject=? AND name=?',(subj['name'],concept_name)).fetchone()
                    if existing:
                        c.execute('UPDATE concepts SET module=? WHERE id=?',(mod['name'],existing['id']))
                    else:
                        c.execute('INSERT INTO concepts VALUES(?,?,?,?)',(str(uuid.uuid4()),subj['name'],mod['name'],concept_name))
init_db()

def syllabus_rows(subject=None):
    out=[]
    for s in SYLLABUS:
        if subject and s['name']!=subject: continue
        for m in s['modules']:
            for concept in m['concepts']:
                out.append({'subject':s['name'],'module':m['name'],'concept':concept})
    return out

def norm(s): return re.sub(r'[^a-z0-9]+',' ',s.lower()).strip()
def split_questions(text):
    """Split on explicit question headings first; avoid treating maths like x=2) as a question."""
    text=text.replace('\r','\n')
    # Past-paper answer keys commonly use headings such as "Question 1" with no punctuation.
    matches=list(re.finditer(r'(?im)^\s*question\s*(\d{1,2})\b',text))
    if len(matches)<2:
        # Fallback for papers using "Q1." or "1." headings, but require a plausible heading line.
        matches=list(re.finditer(r'(?im)^\s*(?:q\s*(\d{1,2})\s*[.):]|(\d{1,2})\s*[.)])\s+(?=[A-ZIfLetEvaluateExpandChangeFindProveShow])',text))
    if len(matches)>=2:
        qs=[]
        for i,m in enumerate(matches):
            chunk=text[m.start():(matches[i+1].start() if i+1<len(matches) else len(text))].strip()
            chunk=re.sub(r'^\s*(?:question\s*\d{1,2}\b|q\s*\d{1,2}\s*[.):]?|\d{1,2}\s*[.)])\s*','',chunk,flags=re.I)
            if len(chunk)>12:
                qno=next((g for g in m.groups() if g),str(i+1))
                qs.append((qno,chunk[:12000]))
        if qs:return qs
    chunks=[x.strip() for x in re.split(r'\n\s*\n+',text) if len(x.strip())>35]
    return [(str(i+1),x[:12000]) for i,x in enumerate(chunks) if len(chunks)<=100]

def match_concepts(question, subject):
    q=norm(question); matches=[]
    for row in syllabus_rows(subject):
        name=row['concept']; terms=[norm(name)]
        # add simple, grounded terminology variants
        aliases={
          'Taylor and Maclaurin expansions':['taylor series','taylor’s series','taylors series','maclaurin series','expand log','third degree term'], 'Maxima and minima of multivariable functions':['maxima minima','maximum minimum','least surface area','minimum surface area','minimum value','find the minimum','maximum value','maxima and minima'],
          'Change of order of integration':['change order integration','reverse order integration','change the order of integration','changed order','order of integration'], 'Gauss divergence theorem':['gauss theorem','divergence theorem'],
          'Green\'s theorem':['greens theorem'], 'Stokes\' theorem':['stokes theorem'], 'Karnaugh-map Boolean simplification':['k map','karnaugh map'],
          'Nernst equation and numerical problems':['nernst equation'], 'UV–Visible spectroscopy: principle, instrumentation and applications':['uv visible spectroscopy','uv vis spectroscopy'],
          'Young\'s double-slit experiment':['double slit experiment','youngs double slit'], 'K-Nearest Neighbours (KNN)':['knn'],
          'Jacobians and functional dependence':['jacobian','jacobians','functional dependence','functionally dependent','functionally dependence','jacobian matrix','determinant of jacobian'],
          'Critical points':['critical point','stationary point','stationary values'],
          'Double integrals and volume under surfaces':['double integral','double integrals','volume under a surface','evaluate over a region','integral over a region','dx dy','dy dx'],
          'Gradient, divergence and curl':['gradient','divergence','curl'],
          'Lagrange multipliers and constrained optimisation':['lagrange multiplier','lagrange method','lagranges method','constrained optimization','constrained optimisation','auxiliary function','under the condition'],
          'Linear differential equations':['linear differential equation'],
          'Partial differential equations':['partial differential equation','pde'],
          'Polar, cylindrical and spherical coordinates':['polar coordinates','cylindrical coordinates','spherical coordinates'],
          'Scalar potential':['scalar potential','potential function'],
          'Irrotational vector fields':['irrotational','curl free'],
          'Solenoidal vector fields':['solenoidal','divergence free'],
          'Lithium-ion secondary batteries':['lithium ion battery','li ion battery'],
          'Hydrogen–oxygen fuel cells':['hydrogen oxygen fuel cell','fuel cell'],
          'Top-down and bottom-up synthesis':['top down synthesis','bottom up synthesis'],
          'Quantum tunnelling and probability':['quantum tunneling','quantum tunnelling'],
          'Karnaugh-map Boolean simplification':['k map','karnaugh map'],
          'Full-wave bridge rectifiers':['bridge rectifier','full wave rectifier'],
          'Thevenin theorem':['thevenin theorem','thevenin equivalent'],
          'Superposition theorem':['superposition theorem'],
          'N-channel enhancement MOSFETs':['n channel mosfet','enhancement mosfet'],
          'Booth and modified Booth multiplication':['booth multiplication','modified booth'],
          'Restoring and non-restoring division':['restoring division','non restoring division'],
          'Cache mapping':['direct mapping','associative mapping','set associative'],
          'Mealy and Moore finite-state machines':['mealy machine','moore machine','finite state machine'],
          'Pauli and Hadamard gates':['pauli gate','hadamard gate'],
          'CNOT gate':['controlled not','cnot'],
          'UV–Visible spectroscopy: principle, instrumentation and applications':['uv visible spectroscopy','uv vis spectroscopy']}
        terms += [norm(x) for x in aliases.get(name.rstrip('.'),[])]
        best=0.0
        for term in terms:
            if len(term)>3 and term in q: best=max(best,0.88 if len(term.split())>1 else 0.68)
        def stem_tokens(value):
            out=[]
            for token in norm(value).split():
                # Lightweight singular/plural normalisation improves matching of e.g. Jacobian/Jacobians.
                out.append(token[:-1] if len(token)>4 and token.endswith('s') else token)
            return out
        q_tokens=set(stem_tokens(q))
        words=[w for w in stem_tokens(name) if len(w)>3]
        if words:
            overlap=sum(w in q_tokens for w in words)/len(words)
            best=max(best,overlap*0.68)
        if best>=0.48: matches.append((row,best))
    return sorted(matches,key=lambda x:x[1],reverse=True)[:5]

def extract_pdf(path):
    """Extract selectable text; for image-only PDFs try optional OCR engines safely."""
    try:
        from pypdf import PdfReader
        reader=PdfReader(str(path))
        page_text=[(page.extract_text() or '').strip() for page in reader.pages]
        page_count=len(reader.pages)
        text='\n\n'.join(t for t in page_text if t)
        if sum(len(t) for t in page_text)<40:
            ocr_text=''
            ocr_errors=[]
            # RapidOCR is optional because ONNX wheels may not support every Python version.
            try:
                import fitz
                from rapidocr_onnxruntime import RapidOCR
                import numpy as np
                engine=RapidOCR(); ocr_pages=[]
                with fitz.open(str(path)) as doc:
                    for i,page in enumerate(doc):
                        pix=page.get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False)
                        arr=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)
                        result,_=engine(arr)
                        words=[str(item[1]) for item in (result or []) if len(item)>1 and item[1]]
                        if words: ocr_pages.append(f'[OCR page {i+1}]\n'+'\n'.join(words))
                ocr_text='\n\n'.join(ocr_pages)
            except Exception as exc:
                ocr_errors.append(f'RapidOCR unavailable: {exc}')
            # Tesseract is an independent fallback, if both its Python wrapper and executable exist.
            if len(ocr_text.strip())<len(text.strip()) or not ocr_text.strip():
                try:
                    import fitz, pytesseract
                    from PIL import Image
                    import io
                    ocr_pages=[]
                    with fitz.open(str(path)) as doc:
                        for i,page in enumerate(doc):
                            pix=page.get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False)
                            image=Image.open(io.BytesIO(pix.tobytes('png')))
                            page_result=pytesseract.image_to_string(image)
                            if page_result.strip(): ocr_pages.append(f'[OCR page {i+1}]\n{page_result}')
                    tess_text='\n\n'.join(ocr_pages)
                    if len(tess_text.strip())>len(ocr_text.strip()): ocr_text=tess_text
                except Exception as exc:
                    ocr_errors.append(f'Tesseract unavailable: {exc}')
            if len(ocr_text.strip())>len(text.strip()): text=ocr_text
            if not text.strip() and ocr_errors:
                # Keep the PDF upload intact; report a useful error instead of crashing the server.
                raise RuntimeError('This PDF appears to be scanned/image-only, but no OCR engine succeeded. Install Tesseract OCR, or run with Python 3.12/3.13 and optional RapidOCR. Details: ' + ' | '.join(ocr_errors[-2:]))
        return text,page_count
    except Exception as e:
        raise RuntimeError(f'Could not read PDF: {e}')

@app.get('/')
def index(): return FileResponse(STATIC/'index.html')
@app.get('/api/subjects')
def subjects(): return {'subjects':SUBJECTS,'exams':EXAMS}
@app.get('/api/papers')
def papers(subject:str|None=None, exam:str|None=None):
    with db() as c:
        sql='SELECT * FROM papers WHERE 1=1'; args=[]
        if subject: sql+=' AND subject=?'; args.append(subject)
        if exam: sql+=' AND exam=?'; args.append(exam)
        rows=c.execute(sql+' ORDER BY created_at DESC',args).fetchall()
        return {'papers':[dict(r) for r in rows]}

@app.post('/api/upload')
async def upload(files:list[UploadFile]=File(...), subject:str=Form(...), exam:str=Form(...), year:str=Form(''), semester:str=Form(''), slot:str=Form('')):
    if subject not in SUBJECTS: raise HTTPException(400,'Choose a valid subject.')
    if exam not in EXAMS: raise HTTPException(400,'Choose CAT-1, CAT-2 or FAT.')
    results=[]
    for f in files:
        if not f.filename or not f.filename.lower().endswith('.pdf'):
            results.append({'filename':f.filename or 'unnamed','status':'rejected','error':'PDF files only.'}); continue
        content=await f.read()
        if len(content)>30*1024*1024:
            results.append({'filename':f.filename,'status':'rejected','error':'File exceeds the 30 MB limit.'}); continue
        if not content.startswith(b'%PDF'):
            results.append({'filename':f.filename,'status':'rejected','error':'File does not appear to be a valid PDF.'}); continue
        digest=hashlib.sha256(content).hexdigest(); pid=str(uuid.uuid4())
        safe=re.sub(r'[^A-Za-z0-9._-]+','_',Path(f.filename).name)[:120]
        stored=f'{digest[:12]}_{safe}'; dest=UPLOADS/stored
        with db() as c:
            old=c.execute('SELECT id FROM papers WHERE sha256=?',(digest,)).fetchone()
            if old:
                results.append({'filename':f.filename,'status':'duplicate','paper_id':old['id'],'error':'This exact PDF has already been uploaded.'}); continue
            dest.write_bytes(content)
            c.execute('INSERT INTO papers VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(pid,f.filename,stored,subject,exam,year,semester,slot,digest,'uploaded','',datetime.datetime.now().isoformat(timespec='seconds')))
        results.append({'filename':f.filename,'status':'uploaded','paper_id':pid})
    return {'results':results}

@app.post('/api/analyse')
def analyse(subject:str=Form(...), exam:str=Form(...)):
    if subject not in SUBJECTS or exam not in EXAMS: raise HTTPException(400,'Invalid subject or exam.')
    output=[]; paper_stats=[]
    with db() as c:
        ps=c.execute('SELECT * FROM papers WHERE subject=? AND exam=? ORDER BY created_at',(subject,exam)).fetchall()
        for p in ps:
            try:
                # Automatic concept matches are the project's labels; no separate evidence-review step is required.
                # Always re-run extraction/matching on Analyse so improved parser/matcher logic
                # also repairs papers analysed by an older project version.
                text,pages=extract_pdf(UPLOADS/p['stored_name'])
                if len(text.strip())<30:
                    c.execute("UPDATE papers SET status='needs_ocr',error=? WHERE id=?",('Little selectable text found. OCR may be required for this scanned PDF.',p['id']))
                    paper_stats.append({'paper_id':p['id'],'filename':p['filename'],'status':'needs_ocr','pages':pages,'questions':0,'matches':0}); continue
                c.execute('DELETE FROM question_concepts WHERE question_id IN (SELECT id FROM questions WHERE paper_id=?)',(p['id'],)); c.execute('DELETE FROM questions WHERE paper_id=?',(p['id'],))
                qs=split_questions(text); mapped=0
                for qno,qtext in qs:
                    qid=str(uuid.uuid4()); c.execute('INSERT INTO questions VALUES(?,?,?,?)',(qid,p['id'],qno,qtext))
                    for row,conf in match_concepts(qtext,subject):
                        cr=c.execute('SELECT id FROM concepts WHERE subject=? AND name=?',(subject,row['concept'])).fetchone()
                        if cr:
                            c.execute('INSERT OR IGNORE INTO question_concepts VALUES(?,?,?,1)',(qid,cr['id'],conf)); mapped+=1
                c.execute("UPDATE papers SET status='processed',error='' WHERE id=?",(p['id'],))
                paper_stats.append({'paper_id':p['id'],'filename':p['filename'],'status':'processed','pages':pages,'questions':len(qs),'matches':mapped})
            except Exception as e:
                c.execute("UPDATE papers SET status='error',error=? WHERE id=?",(str(e),p['id']))
                paper_stats.append({'paper_id':p['id'],'filename':p['filename'],'status':'error','error':str(e),'questions':0,'matches':0})
        rows=c.execute('''SELECT q.id qid,q.paper_id,q.question_no,q.text,qc.confidence,qc.verified,co.name concept,co.module,p.filename,p.exam,p.subject,p.year
          FROM questions q JOIN papers p ON p.id=q.paper_id LEFT JOIN question_concepts qc ON qc.question_id=q.id LEFT JOIN concepts co ON co.id=qc.concept_id
          WHERE p.subject=? AND p.exam=? ORDER BY p.created_at DESC''',(subject,exam)).fetchall()
        for r in rows: output.append(dict(r))
    return {'papers':paper_stats,'summary':{'files':len(paper_stats),'processed':sum(x['status']=='processed' for x in paper_stats),'needs_ocr':sum(x['status']=='needs_ocr' for x in paper_stats),'failed':sum(x['status']=='error' for x in paper_stats),'questions':sum(x['questions'] for x in paper_stats),'matches':sum(x['matches'] for x in paper_stats)},'extracted':output}

class VerifyBody(BaseModel):
    question_id:str
    concepts:list[str]
    verified:bool=True
    corrected_text:str|None=None
@app.post('/api/verify')
def verify(body:VerifyBody):
    with db() as c:
        q=c.execute('SELECT id FROM questions WHERE id=?',(body.question_id,)).fetchone()
        if not q: raise HTTPException(404,'Question not found.')
        if body.corrected_text is not None: c.execute('UPDATE questions SET text=? WHERE id=?',(body.corrected_text,body.question_id))
        c.execute('DELETE FROM question_concepts WHERE question_id=?',(body.question_id,))
        for name in body.concepts:
            row=c.execute('SELECT id FROM concepts WHERE name=?',(name,)).fetchone()
            if row:c.execute('INSERT OR IGNORE INTO question_concepts VALUES(?,?,?,?)',(body.question_id,row['id'],1.0,int(body.verified)))
    return {'saved':True}

@app.post('/api/train')
def train(subject:str=Form(...),exam:str=Form(...)):
    """Train real classifiers from automatically extracted paper/concept labels.

    Target: concept appears in a processed paper (1), or was not matched (0).
    Features combine one-hot concept/module identity and historical recurrence that
    uses only papers earlier than each training row. Unmatched labels are weak negatives.
    """
    if subject not in SUBJECTS: raise HTTPException(400,'Choose a valid subject.')
    if exam not in EXAMS: raise HTTPException(400,'Choose CAT-1, CAT-2 or FAT.')
    with db() as c:
        # A new training attempt invalidates prior estimates for this selection.
        c.execute("UPDATE model_runs SET status='superseded' WHERE subject=? AND exam=? AND status='trained'",(subject,exam))
        c.execute('DELETE FROM model_estimates WHERE subject=? AND exam=?',(subject,exam))
        def untrained(message, processed, rows=0, positives=0):
            stamp=datetime.datetime.now().isoformat(timespec='seconds')
            for model_name in ('Decision Tree','KNN'):
                c.execute('INSERT INTO model_runs VALUES(?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),model_name,subject,exam,rows,json.dumps({'message':message,'automatic_positive_labels':positives}), 'insufficient_data',stamp))
            return {'status':'insufficient_data','message':message,'processed_papers':processed,'training_rows':rows,'automatic_positive_labels':positives,'models':[]}
        papers=c.execute("SELECT id,year,created_at FROM papers WHERE subject=? AND exam=? AND status='processed' ORDER BY COALESCE(NULLIF(year,''),'0000'),created_at,id",(subject,exam)).fetchall()
        concepts=c.execute('SELECT id,subject,module,name FROM concepts WHERE subject=? ORDER BY module,name',(subject,)).fetchall()
        if not papers:
            return untrained('No processed PDFs for this subject and exam yet. Upload a readable PDF and click Analyse uploaded papers. There is no minimum paper count.',0)
        matches=c.execute("SELECT DISTINCT q.paper_id,qc.concept_id FROM question_concepts qc JOIN questions q ON q.id=qc.question_id JOIN papers p ON p.id=q.paper_id WHERE p.subject=? AND p.exam=? AND p.status='processed'",(subject,exam)).fetchall()
        present={(r['paper_id'],r['concept_id']) for r in matches}
        total=len(papers); nconcepts=len(concepts)
        if not nconcepts:
            return untrained('No syllabus concepts are configured for this subject.',total)
        modules=sorted({r['module'] for r in concepts}); module_ix={v:i for i,v in enumerate(modules)}
        feature_len=nconcepts+len(modules)+4
        def features(ci,prior_count,prior_total,age):
            co=concepts[ci]; v=[0.0]*feature_len
            v[ci]=1.0; v[nconcepts+module_ix[co['module']]]=1.0
            base=nconcepts+len(modules)
            v[base]=float(prior_count); v[base+1]=float(prior_count/max(1,prior_total))
            v[base+2]=float(age); v[base+3]=float(prior_total)
            return v
        X=[]; y=[]; row_paper=[]; cumulative={r['id']:0 for r in concepts}; earlier=0
        for pi,paper in enumerate(papers):
            pid=paper['id']; positives={cid for pp,cid in present if pp==pid}
            for ci,co in enumerate(concepts):
                prior_count=cumulative[co['id']]
                last_seen=max((j for j,oldp in enumerate(papers[:pi]) if (oldp['id'],co['id']) in present),default=-1)
                age=(earlier-last_seen) if last_seen>=0 else earlier+1
                X.append(features(ci,prior_count,earlier,age)); y.append(int((pid,co['id']) in present)); row_paper.append(pid)
            for cid in positives: cumulative[cid]+=1
            earlier+=1
        try:
            import numpy as np
            from sklearn.tree import DecisionTreeClassifier
            from sklearn.neighbors import KNeighborsClassifier
            from sklearn.pipeline import make_pipeline
            from sklearn.preprocessing import StandardScaler
            from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,confusion_matrix
            X=np.asarray(X,dtype=float); y=np.asarray(y,dtype=int)
            positive_rows=int(y.sum()); total_rows=int(len(y))
            if positive_rows==0:
                return untrained('The PDFs were processed, but automatic concept matching found no positive labels. The models were not trained on fabricated all-zero labels. Try a readable PDF, check OCR, or upload a paper with questions that match the syllabus.',total,total_rows,0)
            if len(set(y))<2:
                return untrained('The extracted dataset has only one target class. A binary classifier cannot learn a meaningful distinction yet. Check extraction or add a paper with different concept coverage; there is no three-paper minimum.',total,total_rows,positive_rows)
            # A temporal holdout tests the newest paper. Validation is only reported when
            # enough earlier papers exist and their labels contain both classes.
            test_mask=np.array([pid==papers[-1]['id'] for pid in row_paper]) if total>=3 else np.zeros(len(y),dtype=bool)
            tr=np.where(~test_mask)[0]; te=np.where(test_mask)[0]
            validation_ok=bool(total>=3 and len(te)>0 and len(set(y[tr]))==2)
            future_X=[]
            for ci,co in enumerate(concepts):
                count=cumulative[co['id']]
                last_seen=max((j for j,paper in enumerate(papers) if (paper['id'],co['id']) in present),default=-1)
                age=(total-last_seen) if last_seen>=0 else total+1
                future_X.append(features(ci,count,total,age))
            future_X=np.asarray(future_X,dtype=float)
            model_specs=[('Decision Tree',DecisionTreeClassifier(max_depth=6,min_samples_leaf=1,class_weight='balanced',random_state=42)),('KNN',make_pipeline(StandardScaler(),KNeighborsClassifier(n_neighbors=max(1,min(5,len(X))),weights='distance')))]
            result=[]; run_at=datetime.datetime.now().isoformat(timespec='seconds')
            for name,model in model_specs:
                metrics={}
                if validation_ok:
                    try:
                        model.fit(X[tr],y[tr]); pred=model.predict(X[te])
                        metrics={'accuracy':round(float(accuracy_score(y[te],pred)),3),'precision':round(float(precision_score(y[te],pred,zero_division=0)),3),'recall':round(float(recall_score(y[te],pred,zero_division=0)),3),'f1':round(float(f1_score(y[te],pred,zero_division=0)),3),'confusion_matrix':confusion_matrix(y[te],pred,labels=[0,1]).tolist(),'validation':'latest-paper holdout','test_rows':int(len(te))}
                    except Exception as exc: metrics={'validation':'unavailable','reason':str(exc)}
                model.fit(X,y)
                classes=list(model.classes_) if hasattr(model,'classes_') else list(model[-1].classes_)
                probs=model.predict_proba(future_X)
                pos_ix=classes.index(1) if 1 in classes else None
                estimates=probs[:,pos_ix] if pos_ix is not None else np.zeros(len(concepts))
                c.execute('INSERT INTO model_runs VALUES(?,?,?,?,?,?,?,?)',(str(uuid.uuid4()),name,subject,exam,total_rows,json.dumps(metrics),'trained',run_at))
                for ci,co in enumerate(concepts):
                    c.execute('INSERT OR REPLACE INTO model_estimates VALUES(?,?,?,?,?,?)',(subject,exam,co['id'],name,round(float(estimates[ci]),6),run_at))
                result.append({'model':name,'status':'trained','metrics':metrics,'validation_available':bool(metrics.get('validation')=='latest-paper holdout'),'training_rows':total_rows,'positive_labels':positive_rows})
            msg=f'Both models trained successfully on {total_rows} paper–concept rows from {total} processed paper(s), including {positive_rows} automatically matched positive labels. '
            msg+='The latest paper was held out for temporal validation.' if validation_ok and result[0]['metrics'].get('validation')=='latest-paper holdout' else 'Validation metrics are unavailable because the dataset is too small for a defensible temporal holdout.'
            msg+=' Automatic matches are weak labels; unmatched concepts are treated as absent, so false negatives and OCR/mapping errors can affect estimates. Predictions are exploratory, not guarantees.'
            return {'status':'trained','message':msg,'processed_papers':total,'training_rows':total_rows,'automatic_positive_labels':positive_rows,'models':result}
        except Exception as e:
            raise HTTPException(500,f'Model training failed: {e}')

@app.get('/api/predictions')
def predictions(subject:str,exam:str):
    with db() as c:
        papers=c.execute('SELECT id,filename,status FROM papers WHERE subject=? AND exam=?',(subject,exam)).fetchall(); pids=[p['id'] for p in papers if p['status']=='processed']; denominator=len(pids)
        rows=c.execute('SELECT * FROM concepts WHERE subject=? ORDER BY module,name',(subject,)).fetchall()
        counts=c.execute('''SELECT co.id cid,COUNT(DISTINCT q.paper_id) n FROM question_concepts qc JOIN questions q ON q.id=qc.question_id JOIN papers p ON p.id=q.paper_id JOIN concepts co ON co.id=qc.concept_id WHERE p.subject=? AND p.exam=? AND qc.verified=1 GROUP BY co.id''',(subject,exam)).fetchall(); cnt={r['cid']:r['n'] for r in counts}
        models=c.execute('SELECT model,status,metrics,samples,created_at FROM model_runs WHERE subject=? AND exam=? ORDER BY created_at DESC, rowid DESC',(subject,exam)).fetchall()
        estimates=c.execute('SELECT concept_id,model,estimate FROM model_estimates WHERE subject=? AND exam=?',(subject,exam)).fetchall(); est={(e['concept_id'],e['model']):e['estimate'] for e in estimates}
        latest={}
        for m in models:
            if m['model'] not in latest: latest[m['model']]=dict(m)
        model_ok=all(k in latest and latest[k]['status']=='trained' for k in ('Decision Tree','KNN'))
        out=[]
        for r in rows:
            n=cnt.get(r['id'],0); out.append({'id':r['id'],'module':r['module'],'concept':r['name'],'papers_with_evidence':n,'total_processed_papers':denominator,'recurrence_pct':round(n/denominator*100,1) if denominator else None,'decision_tree_estimate':(round(est[(r['id'],'Decision Tree')]*100,1) if (r['id'],'Decision Tree') in est else None),'knn_estimate':(round(est[(r['id'],'KNN')]*100,1) if (r['id'],'KNN') in est else None),'status':'Historical evidence available' if n else ('No automatic match detected in uploaded papers' if denominator else 'No analysed papers yet')})
        return {'predictions':out,'summary':{'processed_papers':denominator,'concepts':len(out),'concepts_with_evidence':sum(x['papers_with_evidence']>0 for x in out),'verified_mappings':sum(cnt.values()),'models_trained':model_ok,'model_status':{k:v['status'] for k,v in latest.items()}},'models':[{'model':k,'status':v['status'],'metrics':json.loads(v['metrics'] or '{}'),'samples':v['samples']} for k,v in latest.items()]}

@app.post('/api/clear-papers')
def clear_previous_papers():
    """Delete uploaded PDFs and all derived analysis/model data, preserving syllabus and concepts."""
    removed_files = 0
    # Remove uploaded PDFs that the database knows about, then any orphaned files in uploads.
    for folder in (UPLOADS, DATA/'processed'):
        folder.mkdir(parents=True, exist_ok=True)
        for item in folder.iterdir():
            try:
                if item.is_file() or item.is_symlink():
                    item.unlink()
                    removed_files += 1
                elif item.is_dir():
                    shutil.rmtree(item)
                    removed_files += 1
            except OSError as exc:
                raise HTTPException(500, f'Could not remove {item.name}: {exc}')
    with db() as c:
        # Delete children before parents. Keep concepts and the bundled syllabus intact.
        c.execute('DELETE FROM question_concepts')
        c.execute('DELETE FROM questions')
        c.execute('DELETE FROM model_estimates')
        c.execute('DELETE FROM model_runs')
        c.execute('DELETE FROM papers')
    return {'cleared': True, 'removed_files': removed_files, 'message': 'Previous papers, extracted questions, concept mappings and model results were cleared. Syllabus and concepts were preserved.'}

@app.get('/api/metrics')
def metrics():
    with db() as c:
        return {'papers':c.execute('SELECT COUNT(*) FROM papers').fetchone()[0],'questions':c.execute('SELECT COUNT(*) FROM questions').fetchone()[0],'verified_mappings':c.execute('SELECT COUNT(*) FROM question_concepts WHERE verified=1').fetchone()[0]}
